from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

app = Flask(__name__)

# Load the trained model
model = joblib.load('model.pkl')

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/')
def status():
    return render_template('status.html')
@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        # Get the form data
        A_id = int(request.form['A_id'])
        Size = float(request.form['Size'])
        Weight = float(request.form['Weight'])
        Sweetness = float(request.form['Sweetness'])
        Crunchiness = float(request.form['Crunchiness'])
        Juiciness = float(request.form['Juiciness'])
        Ripeness = float(request.form['Ripeness'])
        Acidity = float(request.form['Acidity'])

        # Create a DataFrame with the input data
        input_data = pd.DataFrame([[A_id, Size, Weight, Sweetness, Crunchiness, Juiciness, Ripeness, Acidity]],
                                  columns=['A_id', 'Size', 'Weight', 'Sweetness', 'Crunchiness', 'Juiciness', 'Ripeness', 'Acidity'])

        # Scale the input data
        scaler = StandardScaler()
        input_data_scaled = scaler.fit_transform(input_data)

        # Make a prediction
        prediction = model.predict(input_data_scaled)

        # Determine the quality label based on the prediction (this depends on your model output)
        if prediction == 0:
            quality = 'Low'
        else:
            quality = 'High'

        return render_template('output.html', quality=quality)

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
